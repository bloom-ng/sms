<div class="overlay w-100 h-100 text-center" 
    v-show="app_loading" 
    style="position:absolute;">
<i class="fas fa-2x fa-spinner fa-spin "></i>
<br>

</div>