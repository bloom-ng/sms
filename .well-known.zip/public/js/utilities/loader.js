export default {
     
    template: `
        <div class="overlay w-100 h-100 text-center" 
    style="position:absolute;">
<i class="fas fa-2x fa-spinner fa-spin "></i>
<br>

</div>
    `
}